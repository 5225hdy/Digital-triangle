﻿#include "widget_copy.h"

widget_copy::widget_copy(QWidget *parent) : QWidget(parent)
{

}
