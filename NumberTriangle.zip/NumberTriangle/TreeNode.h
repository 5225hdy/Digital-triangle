﻿#ifndef TREE_H
#define TREE_H


class TreeNode
{
public:
    TreeNode *left = nullptr;
    TreeNode *right = nullptr;
    int val = 0;
    TreeNode(int val);
};

#endif // TREE_H
