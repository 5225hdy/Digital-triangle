﻿#include "TreeNode.h"

TreeNode::TreeNode(int val)
{
    this->val = val;
}
