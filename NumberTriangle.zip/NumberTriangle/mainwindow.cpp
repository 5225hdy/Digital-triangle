﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#define Max 6

using namespace std;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //背景音乐
    playlist = new QMediaPlaylist;
    player = new QMediaPlayer;
    connect(&PlaTimer,&QTimer::timeout,this,&MainWindow::PlaTimerListener);
    player->setMedia(QUrl("qrc:/image/img/b.mp3"));
    player->setVolume(40);//z
    player->play();//
    //设置定时器
    PlaTimer.setInterval(170000);//定时170s
    PlaTimer.start();

    //按钮音效
    playerButn=new QMediaPlayer;
    playerButn->setMedia(QUrl("qrc:/image/img/a.mp3"));
    playerButn->setVolume(40);
    //错误提示音
    playerror =new QMediaPlayer();
    playerror->setMedia(QUrl("qrc:/image/img/c.mp3"));
    playerror->setVolume(80);
}

MainWindow::~MainWindow()
{
    delete ui;
}
//定时器
void MainWindow::PlaTimerListener(){
    player->setPosition(0);
    player->play();
}

void MainWindow::on_pushButton_3_clicked()
{
    playerButn->play();//添加音效
    this->close();
}

void MainWindow::on_pushButton_4_clicked()
{
    playerButn->play();//添加音效
    ui->tabWidget->setCurrentIndex(1);
    ui->pushButton_7->setStyleSheet("QPushButton{border-image: url(:/image/img/home off.png);}"
                                    "QPushButton:hover{border-image:url(:/image/img/home on.png);}");
    ui->pushButton_8->setStyleSheet("QPushButton{border-image: url(:/image/img/program.png);}");
    ui->pushButton_9->setStyleSheet("QPushButton{border-image: url(:/image/img/about off.png);}"
                                    "QPushButton:hover{border-image: url(:/image/img/about on.png);}");
}
void MainWindow::on_pushButton_6_clicked()
{
    playerButn->play();//添加音效
    this->close();
}

void MainWindow::on_pushButton_5_clicked()
{
    playerButn->play();//添加音效
    ui->tabWidget->setCurrentIndex(1);
    ui->pushButton_7->setStyleSheet("QPushButton{border-image: url(:/image/img/home off.png);}"
                                    "QPushButton:hover{border-image:url(:/image/img/home on.png);}");
    ui->pushButton_8->setStyleSheet("QPushButton{border-image: url(:/image/img/program.png);}");
    ui->pushButton_9->setStyleSheet("QPushButton{border-image: url(:/image/img/about off.png);}"
                                    "QPushButton:hover{border-image: url(:/image/img/about on.png);}");
}
//开始程序按钮
void MainWindow::on_pushButton_clicked()
{
    erroDialog=new ErrorDialog();//创建弹窗对象
    int num=ui->lineEdit->text().toInt();
    if(num>=1 && num<=5)
    {
        MaxSum(num);
        triangle(num);

    }else
    {
        playerror->play();
        ui->lineEdit->clear();
        ui->label->clear();
        ui->label_2->clear();
        erroDialog->show();//弹窗显示
    }
}
//寻找最大和，递推型动归
int D[Max][Max];//未改变的随机数
int C[Max][Max];//改变随机数
vector<vector<int>> all_path;
/*
void printArray(int arr[][Max]){
    cout << "[" << endl;
    for(int i = 0; i<Max;i++){
        cout << "[";
        for(int j = 0; j<Max;j++){
            cout << arr[i][j] << ",";
        }
        cout << "]" << endl;
    }
    cout << "]" << endl;
}
*/
void find_path(TreeNode* root, int sum, vector<int>& sub_path) {
    if (root == nullptr || all_path.size() >= 1) {
        return;
    }
    sub_path.emplace_back(root->val);
    if (sum == root->val && root->left == nullptr && root->right == nullptr) {
        all_path.emplace_back(sub_path);
    }
    find_path(root->left, sum - root->val, sub_path);
    find_path(root->right, sum - root->val, sub_path);
    sub_path.pop_back();
}

vector<vector<int>> pathSum(TreeNode* root, int sum) {
    if (root == nullptr) {
        return all_path;
    }
    all_path.clear();
    vector<int> sub_path;
    find_path(root, sum, sub_path);
    return all_path;
}
//坐标
void generateTreeNode(TreeNode *root){
    // 2
    root->left = new TreeNode(D[2][1]);
    root->right = new TreeNode(D[2][2]);
    // 3
    root->left->left = new TreeNode(D[3][1]);
    root->left->right = new TreeNode(D[3][2]);
    root->right->right = new TreeNode(D[3][3]);
    //
    root->right->left = new TreeNode(D[3][2]);
    // 4
    root->left->left->left = new TreeNode(D[4][1]);
    root->left->left->right = new TreeNode(D[4][2]);
    root->right->right->left = new TreeNode(D[4][3]);
    root->right->right->right = new TreeNode(D[4][4]);
    //
    root->left->right->left = new TreeNode(D[4][2]);
    root->left->right->right = new TreeNode(D[4][3]);
    root->right->left->left = new TreeNode(D[4][2]);
    root->right->left->right = new TreeNode(D[4][3]);
    // 5
    root->left->left->left->left = new TreeNode(D[5][1]);
    root->left->left->left->right = new TreeNode(D[5][2]);

    root->left->left->right->right = new TreeNode(D[5][3]);

    root->right->right->right->left = new TreeNode(D[5][4]);
    root->right->right->right->right = new TreeNode(D[5][5]);
    //
    root->left->left->right->left = new TreeNode(D[5][2]);

    root->left->right->left->left = new TreeNode(D[5][2]);
    root->left->right->left->right = new TreeNode(D[5][3]);

    root->left->right->right->left = new TreeNode(D[5][3]);
    root->left->right->right->right = new TreeNode(D[5][4]);

    root->right->right->left->left = new TreeNode(D[5][3]);
    root->right->right->left->right = new TreeNode(D[5][4]);

    root->right->left->right->left = new TreeNode(D[5][3]);
    root->right->left->right->right = new TreeNode(D[5][4]);

    root->right->left->left->left = new TreeNode(D[5][2]);
    root->right->left->left->right = new TreeNode(D[5][3]);
}

TreeNode* root;

std::vector<int> CreateRandomNums(int min,int max, int num)
{
    std::vector<int> res;
    res.clear();
    if (max - min + 1 < num)
    {
        return res;
    }
    srand(time(0));
    for (auto i{0}; i < num; i++)
    {
        while (true)
        {
            auto temp{ rand() % (max + 1 - min) + min };
            auto iter{ find(res.begin(),res.end(),temp) };
            if (res.end() == iter)
            {
                res.push_back(temp);
                break;
            }
        }
    }
    return res;
}

void MainWindow::drawNode(int rootX,int rootY,int paddingX,int paddingY, int num){
    painter->drawEllipse(rootX,rootY,84,84);//(坐标x,坐标y,圆长，圆宽)
    if(num >= 10){
        painter->drawText(rootX + 25,rootY + 48,QString::number(num));//字体坐标
    }else{
        painter->drawText(rootX + 37,rootY + 48,QString::number(num));//字体坐标
    }
}

void MainWindow::delayMS(unsigned int msec)
{
    QTime timer = QTime::currentTime().addMSecs(msec);
    while( QTime::currentTime() < timer )
        QCoreApplication::processEvents(QEventLoop::AllEvents,100);
}

void MainWindow::drawTree(TreeNode *root, int rootX,int rootY, int paddingX, int paddingY, int layer, int num){
    if(root == nullptr || layer + 1 > num){
        return;
    }
    drawNode(rootX,rootY,paddingX,paddingY,root->val);
    drawTree(root->left, rootX - paddingX, rootY + paddingY, paddingX, paddingY, layer+1, num);
    drawTree(root->right, rootX + paddingX, rootY + paddingY, paddingX, paddingY, layer+1, num);
}

vector<int> path;

int MainWindow::MaxSum(int num)
{
    //清除
    memset(D,0,sizeof(D));
    memset(C,0,sizeof(C));

    int i,j;
    vector<int> randoms = CreateRandomNums(0,20,15);
    int sum = 0;
    for(i=1;i<=num;i++)
    {
        for (j=1;j<=i;j++)
        {
            D[i][j]=randoms.at(sum++);
        }
    }
    for(i=1;i<=num;i++)
    {
        for (j=1;j<=i;j++)
        {
            C[i][j]=D[i][j];
        }
    }

    for(i=num-1;i>=1;i--)
    {
        for (j=1;j<=i;j++)
        {
            C[i][j]=qMax(C[i + 1][j], C[i + 1][j + 1]) + C[i][j];
        }
    }

    // root
    root = new TreeNode(D[1][1]);
    generateTreeNode(root);

    vector<vector<int>> paths = pathSum(root,C[1][1]);
    path.clear();
    path = paths.at(0);
    return C[1][1];
}


void MainWindow::triangle(int num)
{
    //画板
    pix = new QPixmap(896,520);
    pix->fill(Qt::transparent);//透明背景
    painter=new QPainter(pix);//创建画家对象指向画板

    ui->label->setPixmap(*pix);
    QFont font("微软雅黑",20,QFont::Bold);
    painter->setFont(font);

    QPen pen;
    brush = new QBrush();
    brush->setColor(QColor(249,217,161));//背景色
    brush->setStyle(Qt::SolidPattern);//实心
    painter->setBrush(*brush);
    pen.setColor(QColor(255,255,255));
    painter->setPen(pen);

    // 根节点的x坐标
    int rootX = 404;
    // 根节点的y坐标
    int rootY = 20;
    // 层数
    int layer = 0;
    int paddingX = 96;
    int paddingY = 99;
    drawTree(root, rootX, rootY, paddingX, paddingY, layer, num);
    ui->label->setPixmap(*pix);
    int sum = 0;
    brush2 = new QBrush();
    brush2->setStyle(Qt::SolidPattern);//实心
    brush2->setColor(QColor(163,237,255));//背景色
    painter->setBrush(*brush2);
    int nodeX = rootX;
//    cout << "------------" << endl;
    for(int x = 1; x <= num; x++){
        for(int y = 1; y <= x;y++){
            if(path.at(sum) == D[x][y]){
                delayMS(700);
                // draw
                drawNode(nodeX,rootY,paddingX,paddingY,D[x][y]);
                playerButn->setPosition(0);
                playerButn->play();
                ui->label->setPixmap(*pix);
//                cout << "x: " << nodeX << " ,y: " << rootY << endl;
                rootY += paddingY;
                sum++;
                break;
            }
            nodeX += 2 * paddingX;
        }
        nodeX = -x * paddingX + rootX;
    }
    ui->label_2->setText(QString::number(C[1][1]));
}

//首页
void MainWindow::on_pushButton_7_clicked()
{
    playerButn->play();//添加音效
    //页面跳转
    ui->tabWidget->setCurrentIndex(0);
    //按钮底色切换
    ui->pushButton_7->setStyleSheet("QPushButton{border-image: url(:/image/img/home on.png);}");
    ui->pushButton_8->setStyleSheet("QPushButton{border-image: url(:/image/img/program off.png);}"
                                    "QPushButton:hover{border-image:url(:/image/img/program.png);}");
    ui->pushButton_9->setStyleSheet("QPushButton{border-image: url(:/image/img/about off.png);}"
                                    "QPushButton:hover{border-image: url(:/image/img/about on.png);}");
}
//程序
void MainWindow::on_pushButton_8_clicked()
{
    playerButn->play();//添加音效
    ui->tabWidget->setCurrentIndex(1);
    ui->pushButton_8->setStyleSheet("QPushButton{border-image: url(:/image/img/program.png);}");
    ui->pushButton_7->setStyleSheet("QPushButton{border-image: url(:/image/img/home off.png);}"
                                    "QPushButton:hover{border-image: url(:/image/img/home on.png);}");
    ui->pushButton_9->setStyleSheet("QPushButton{border-image: url(:/image/img/about off.png);}"
                                    "QPushButton:hover{border-image: url(:/image/img/about on.png);}");
}
//关于
void MainWindow::on_pushButton_9_clicked()
{
    playerButn->play();//添加音效
    ui->tabWidget->setCurrentIndex(2);
    ui->pushButton_9->setStyleSheet("QPushButton{border-image:url(:/image/img/about on.png);}");
    ui->pushButton_7->setStyleSheet("QPushButton{border-image:url(:/image/img/home off.png);}"
                                    "QPushButton:hover{border-image:url(:/image/img/home on.png);}");
    ui->pushButton_8->setStyleSheet("QPushButton{border-image:url(:/image/img/program off.png);}"
                                    "QPushButton:hover{border-image:url(:/image/img/program.png);}");
}
//重新开始
void MainWindow::on_pushButton_2_clicked()
{
    playerButn->play();//添加音效
    ui->lineEdit->clear();
    ui->label->clear();
    ui->label_2->clear();
}

//音乐开始按钮
int music_flag=0;
void MainWindow::on_pushButton_10_clicked()
{
    playerButn->play();//添加音效
    //ui->pushButton_10->setStyleSheet("QPushButton:{border-image:url(:/image/img/stop.png);}");
    if(music_flag==0)
    {
        player->pause();
        ui->pushButton_10->setStyleSheet("border-image: url(:/image/img/start.png)");
        music_flag=1;
    }
    else if(music_flag==1)
    {
        player->play();
        ui->pushButton_10->setStyleSheet("border-image: url(:/image/img/stop.png)");
        music_flag=0;
    }
}

//音量-
void MainWindow::on_pushButton_12_clicked()
{
    playerButn->play();//添加音效
}
//音量+
void MainWindow::on_pushButton_13_clicked()
{
    playerButn->play();//添加音效
}

void MainWindow::on_pushButton_11_clicked()
{
    playerButn->play();//添加音效
}

