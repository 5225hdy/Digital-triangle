﻿#ifndef WIDGET_COPY_H
#define WIDGET_COPY_H

#include <QWidget>

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit widget_copy(QWidget *parent = nullptr);

signals:

};

#endif // WIDGET_COPY_H
