﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPushButton>
#include <QPixmap>
#include <QPainter>
#include <QTime>
#include <QtAlgorithms>
#include <QFont>
#include <QTextBlock>
#include <QPen>
#include <QtMultimedia/QMediaPlayer>//音乐
#include <QMediaPlaylist>
#include <QTimer>
#include <QPoint>
#include "errordialog.h"
#include <QQueue>
#include <iostream>
#include "TreeNode.h"
#include "time.h"
#include <synchapi.h>
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    //QTime* time;
    void delayMS(unsigned int msec);
    void drawNode(int rootX,int rootY,int paddingX,int paddingY, int num);
    void drawTree(TreeNode *root, int rootX,int rootY, int paddingX, int paddingY, int layer, int num);
    void PlaTimerListener();//定时器

    void triangle(int num);//数字三角形

    int MaxSum(int num);//算法

private slots:
    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_clicked();


    void on_pushButton_6_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_7_clicked();

    void on_pushButton_8_clicked();

    void on_pushButton_9_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_10_clicked();

    void on_pushButton_12_clicked();

    void on_pushButton_13_clicked();

    void on_pushButton_11_clicked();






private:
    Ui::MainWindow *ui;
    //实例化音乐对象
    QMediaPlayer* player,*playerButn,*playerror;
    QMediaPlaylist *playlist;

    QTimer PlaTimer;//定时器
    ErrorDialog* erroDialog;//弹窗
    QQueue<QPoint> queue;
    QPixmap *pix;
    QPainter *painter;
    QBrush *brush;
    QBrush *brush2;
};

#endif // MAINWINDOW_H
